CREATE VIEW viewclient AS
  SELECT
    `domiciliation`.`clients`.`idclient`                  AS `idclient`,
    `domiciliation`.`clients`.`codeclient`                AS `codeclient`,
    `domiciliation`.`clients`.`nomclient`                 AS `nomclient`,
    `domiciliation`.`clients`.`siren`                     AS `siren`,
    `domiciliation`.`clients`.`datecontract`              AS `datecontract`,
    `domiciliation`.`clients`.`capital`                   AS `capital`,
    `domiciliation`.`clients`.`formejuridique`            AS `formejuridique`,
    `domiciliation`.`responsablelegale`.`nomcomplet`      AS `nomcomplet`,
    `domiciliation`.`responsablelegale`.`datenaissance`   AS `datenaissance`,
    `domiciliation`.`responsablelegale`.`lieunaissance`   AS `lieunaissance`,
    `domiciliation`.`responsablelegale`.`nationalite`     AS `nationalite`,
    `domiciliation`.`responsablelegale`.`function`        AS `function`,
    `domiciliation`.`responsablelegale`.`telephone`       AS `telephone`,
    `domiciliation`.`responsablelegale`.`email`           AS `email`,
    `domiciliation`.`responsablelegale`.`adresse`         AS `adresse`,
    `domiciliation`.`contract`.`idcontract`               AS `idcontract`,
    `domiciliation`.`contract`.`debutcontract`            AS `debutcontract`,
    `domiciliation`.`contract`.`fincontract`              AS `fincontract`,
    `domiciliation`.`contract`.`optioncontract`           AS `optioncontract`,
    `domiciliation`.`contract`.`addnotation`              AS `addnotation`,
    `domiciliation`.`justificatif`.`pieceidentite`        AS `pieceidentite`,
    `domiciliation`.`justificatif`.`justificatifdomicile` AS `justificatifdomicile`,
    `domiciliation`.`justificatif`.`procurationpostale`   AS `procurationpostale`,
    `domiciliation`.`justificatif`.`contractsigne`        AS `contractsigne`
  FROM (((`domiciliation`.`clients`
    JOIN `domiciliation`.`responsablelegale`) JOIN `domiciliation`.`contract`) JOIN `domiciliation`.`justificatif`);

