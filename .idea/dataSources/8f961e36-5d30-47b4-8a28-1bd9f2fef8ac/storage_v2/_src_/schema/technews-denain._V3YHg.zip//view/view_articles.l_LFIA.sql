CREATE VIEW view_articles AS
  SELECT
    `technews-denain`.`article`.`IDARTICLE`            AS `IDARTICLE`,
    `technews-denain`.`article`.`IDAUTEUR`             AS `IDAUTEUR`,
    `technews-denain`.`article`.`IDCATEGORIE`          AS `IDCATEGORIE`,
    `technews-denain`.`categorie`.`LIBELLECATEGORIE`   AS `LIBELLECATEGORIE`,
    `technews-denain`.`article`.`TITREARTICLE`         AS `TITREARTICLE`,
    `technews-denain`.`article`.`CONTENUARTICLE`       AS `CONTENUARTICLE`,
    `technews-denain`.`article`.`FEATUREDIMAGEARTICLE` AS `FEATUREDIMAGEARTICLE`,
    `technews-denain`.`article`.`SPECIALARTICLE`       AS `SPECIALARTICLE`,
    `technews-denain`.`article`.`SPOTLIGHTARTICLE`     AS `SPOTLIGHTARTICLE`,
    `technews-denain`.`article`.`DATECREATIONARTICLE`  AS `DATECREATIONARTICLE`,
    `technews-denain`.`auteur`.`NOMAUTEUR`             AS `NOMAUTEUR`,
    `technews-denain`.`auteur`.`PRENOMAUTEUR`          AS `PRENOMAUTEUR`,
    `technews-denain`.`auteur`.`EMAILAUTEUR`           AS `EMAILAUTEUR`
  FROM ((`technews-denain`.`article`
    JOIN `technews-denain`.`auteur`) JOIN `technews-denain`.`categorie`)
  WHERE ((`technews-denain`.`article`.`IDAUTEUR` = `technews-denain`.`auteur`.`IDAUTEUR`) AND
         (`technews-denain`.`article`.`IDCATEGORIE` = `technews-denain`.`categorie`.`IDCATEGORIE`));

