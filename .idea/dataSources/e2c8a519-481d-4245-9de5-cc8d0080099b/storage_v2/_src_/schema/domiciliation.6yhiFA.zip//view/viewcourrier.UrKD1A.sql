CREATE VIEW viewcourrier AS
  SELECT
    `domiciliation`.`courrier`.`idcourrier`                    AS `idcourrier`,
    `domiciliation`.`courrier`.`numerocourrier`                AS `numerocourrier`,
    `domiciliation`.`courrier`.`dateentre`                     AS `dateentre`,
    `domiciliation`.`courrier`.`datesortie`                    AS `datesortie`,
    `domiciliation`.`courrier`.`adressereexpedition`           AS `adressereexpedition`,
    `domiciliation`.`courrier`.`email`                         AS `email`,
    `domiciliation`.`courrier`.`addnotation`                   AS `addnotation`,
    `domiciliation`.`clients`.`idclient`                       AS `idclient`,
    `domiciliation`.`clients`.`nomclient`                      AS `nomclient`,
    `domiciliation`.`clients`.`codeclient`                     AS `codeclient`,
    `domiciliation`.`typecourrier`.`idtypecourrier`            AS `idtypecourrier`,
    `domiciliation`.`typecourrier`.`libellecourrier`           AS `libellecourrier`,
    `domiciliation`.`voiereexpedition`.`idvoiereexpedition`    AS `idvoiereexpedition`,
    `domiciliation`.`voiereexpedition`.`libellereexpedition`   AS `libellereexpedition`,
    `domiciliation`.`tarif`.`idtarif`                          AS `idtarif`,
    `domiciliation`.`tarif`.`typedenvoie`                      AS `typedenvoie`,
    `domiciliation`.`tarif`.`tarifenvoie`                      AS `tarifenvoie`,
    `domiciliation`.`tarif`.`tarifenvelope`                    AS `tarifenvelope`,
    `domiciliation`.`contract`.`optioncontract`                AS `optioncontract`,
    `domiciliation`.`lettresrecommandees`.`numerodenvoie`      AS `numerodenvoie`,
    `domiciliation`.`lettresrecommandees`.`typelettre`         AS `typelettre`,
    `domiciliation`.`lettresrecommandees`.`expediteur`         AS `expediteur`,
    `domiciliation`.`lettresrecommandees`.`idlettrerecommande` AS `idlettrerecommande`
  FROM ((((((`domiciliation`.`courrier`
    JOIN `domiciliation`.`clients`) JOIN `domiciliation`.`typecourrier`) JOIN `domiciliation`.`voiereexpedition`) JOIN
    `domiciliation`.`tarif`) JOIN `domiciliation`.`contract`) JOIN `domiciliation`.`lettresrecommandees`);

