CREATE VIEW view_articles AS
  SELECT
    `test`.`courrier`.`id_courrier`           AS `id_courrier`,
    `test`.`courrier`.`id_client`             AS `id_client`,
    `test`.`courrier`.`id_type`               AS `id_type`,
    `test`.`type_courrier`.`libelle_courrier` AS `libelle_courrier`,
    `test`.`courrier`.`date_entre`            AS `date_entre`,
    `test`.`courrier`.`addnotation`           AS `addnotation`,
    `test`.`clients`.`nom_client`             AS `nom_client`
  FROM ((`test`.`courrier`
    JOIN `test`.`clients`) JOIN `test`.`type_courrier`)
  WHERE ((`test`.`courrier`.`id_client` = `test`.`clients`.`id_client`) AND
         (`test`.`courrier`.`id_type` = `test`.`type_courrier`.`id_type`));

