CREATE VIEW view_courrier AS
  SELECT
    `domiciliation`.`courrier`.`id_courrier`                   AS `id_courrier`,
    `domiciliation`.`courrier`.`id_client`                     AS `id_client`,
    `domiciliation`.`courrier`.`id_type_courrier`              AS `id_type_courrier`,
    `domiciliation`.`type_courrier`.`libelle_courrier`         AS `libelle_courrier`,
    `domiciliation`.`courrier`.`date_entre`                    AS `date_entre`,
    `domiciliation`.`courrier`.`annotation`                    AS `annotation`,
    `domiciliation`.`courrier`.`scan`                          AS `scan`,
    `domiciliation`.`courrier`.`date_sortie`                   AS `date_sortie`,
    `domiciliation`.`lettres_recommandees`.`id_lettre`         AS `id_lettre`,
    `domiciliation`.`lettres_recommandees`.`destinateur`       AS `destinateur`,
    `domiciliation`.`lettres_recommandees`.`expediteur`        AS `expediteur`,
    `domiciliation`.`client`.`nom_client`                      AS `nom_client`,
    `domiciliation`.`client`.`code_client`                     AS `code_client`,
    `domiciliation`.`voie_reexpedition`.`libelle_reexpedition` AS `libelle_reexpedition`,
    `domiciliation`.`voie_reexpedition`.`id_reexpedition`      AS `id_reexpedition`,
    `domiciliation`.`tarif`.`tarif_envoie`                     AS `tarif_envoie`
  FROM (((((`domiciliation`.`courrier`
    JOIN `domiciliation`.`client`) JOIN `domiciliation`.`type_courrier`) JOIN
    `domiciliation`.`lettres_recommandees`) JOIN `domiciliation`.`voie_reexpedition`) JOIN `domiciliation`.`tarif`)
  WHERE ((`domiciliation`.`courrier`.`id_client` = `domiciliation`.`client`.`id_client`) AND
         (`domiciliation`.`courrier`.`id_type_courrier` = `domiciliation`.`type_courrier`.`id_type_courrier`) AND
         (`domiciliation`.`lettres_recommandees`.`id_tarif` = `domiciliation`.`tarif`.`id_tarif`));

